//
// Created by marko on 20.4.22..
//
//#include "../h/_sem.hpp"
#ifndef OS1_VEZBE07_RISCV_CONTEXT_SWITCH_2_INTERRUPT_WORKERS_HPP
#define OS1_VEZBE07_RISCV_CONTEXT_SWITCH_2_INTERRUPT_WORKERS_HPP

/*extern static void workerBodyA();

extern static void workerBodyB();

extern static void workerBodyC();

extern static void workerBodyD();*/

void workerTestJoin();


#endif //OS1_VEZBE07_RISCV_CONTEXT_SWITCH_2_INTERRUPT_WORKERS_HPP
